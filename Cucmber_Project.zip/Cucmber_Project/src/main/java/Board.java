
public class Board {

	public void setStarterCell(Robot robot1) {
		
	}

	public void setBoard() {
		
	}
	
	
}
