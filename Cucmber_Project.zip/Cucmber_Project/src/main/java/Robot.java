
public class Robot {
	private RobotColor color;
	
	public Robot(RobotColor c) {
		this.color = c;
	}
	
	public RobotColor getColor() {
		return color;
	}
}
