
public enum RobotColor {
	GREEN, YELLOW, RED, BLUE;
}
