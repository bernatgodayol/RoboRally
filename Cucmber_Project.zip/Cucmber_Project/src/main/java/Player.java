
public class Player {
	private String name;
	private Robot robot;
	
	public Player(String name) {
		this.name = name;
	}
	
	public void setRobot(Robot robot) {
		this.robot = robot;
	}
	
	public Robot getRobot() {
		return robot;
	}
	
	
	
}
